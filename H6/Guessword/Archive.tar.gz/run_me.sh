
make
mpiexec -n 2 ./guessword 1-passwd.txt 1-shadow.txt